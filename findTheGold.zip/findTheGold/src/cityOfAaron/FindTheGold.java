/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
/*
* The main() class file for the cityOfAaron project * CIT-260
* Spring 2018
* Team members: Marshall Evanas, Kelsey Haddow */
package cityOfAaron; 


/**
 *
 * @author khaddow
 */
public class FindTheGold {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
